package teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import dao.MySqlProdutoDAO;
import dao.ProdutoDAO;
import exceptions.FalhaAcessoAosDadosException;
import model.Produto;

public class TestaDAO {

	public TestaDAO() {
	}
	
	private Connection getConnection(String driver, String url, String user, String pwd) {

		Connection conn = null;

		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, pwd);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("N�o foi poss�vel encontrar o driver JDBC");
		} catch (SQLException se) {
			System.out.println("N�o foi poss�vel conectar ao Banco de Dados");
		}

		return conn;
	}
	
	public void operacoes() {
		
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost/minhabase";
		String user = "root";
		String pwd = "";
		
		// Abre conex�o com o banco
		Connection conn = this.getConnection(driver, url, user, pwd);
		
		// Obtem classe de acesso aos dados
		ProdutoDAO dao = new MySqlProdutoDAO(conn);
		
		// Executa a��es na tabela
		try {
//			System.out.println("Apaga todos");
//			
//			dao.apagaTodos();
//			
			System.out.println("Insere produto");

			Produto produto = new Produto(105,"Bola de tenis","Material esportivo");
			dao.insereProduto(produto);
//			
//			System.out.println("Lista produtos");
//			System.out.println("-------------------------------------");
//			
//			for(Produto p : dao.buscaTodos()) {
//				System.out.println(p);
//			}
//			System.out.println("-------------------------------------");
//			
//            Produto produto = new Produto(2,"Coca-cola","Garrafa PET 600ml");
//            dao.insereProduto(produto);
//			
//            System.out.println("Lista produtos");
//			System.out.println("-------------------------------------");
//			
//			for(Produto p : dao.buscaTodos()) {
//				System.out.println(p);
//			}
//			System.out.println("-------------------------------------");
//			
//			System.out.println("Altera produto");
//			
//			Produto p2 = dao.getProdutoPorCodigo(1);
//			p2.setNome(p2.getNome() + " mudou");
//			dao.alteraProduto(p2);
//            
			System.out.println("Lista produtos");
			System.out.println("-------------------------------------");
			
			for(Produto p : dao.buscaTodos()) {
				System.out.println(p);
			}
			System.out.println("-------------------------------------");
//			
//			System.out.println("Remove produto");
//			dao.removeProduto(1);
//			
//			System.out.println("Lista produtos");
//			System.out.println("-------------------------------------");
//			
//			for(Produto p : dao.buscaTodos()) {
//				System.out.println(p);
//			}
//			System.out.println("-------------------------------------");
			
			// Encerra a conex�o ao banco de dados
			conn.close();
			
		} 
		catch (FalhaAcessoAosDadosException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
	
	
}
