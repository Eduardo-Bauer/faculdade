package dao;

import java.util.List;

import exceptions.FalhaAcessoAosDadosException;
import model.Produto;

public interface ProdutoDAO {

	public Produto getProdutoPorCodigo(int cod) throws FalhaAcessoAosDadosException;

	public List<Produto> buscaTodos() throws FalhaAcessoAosDadosException;

	public int insereProduto(Produto produto) throws FalhaAcessoAosDadosException;

	public int alteraProduto(Produto produto) throws FalhaAcessoAosDadosException;

	public int apagaTodos() throws FalhaAcessoAosDadosException;

	public int removeProduto(Integer codigo) throws FalhaAcessoAosDadosException;

}