package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import exceptions.FalhaAcessoAosDadosException;
import exceptions.ProdutoNaoEncontradoException;
import model.Produto;

public class MySqlProdutoDAO extends MySqlDAO implements ProdutoDAO{

	public MySqlProdutoDAO(Connection conn) {
		this.conn = conn;
	}

	@Override
	/**
	 * Retornar um produto
	 * 
	 * @param int cod Recebe o c�digo de um produto para buscar no banco
	 * @return O produto encontrado com o c�digo informado
	 * @throws FalhaAcessoAosDadosException quando n�o encontrar o produto com o c�digo informado
	 */
	public Produto getProdutoPorCodigo(int cod) throws FalhaAcessoAosDadosException {
		
		System.out.println("Buscando o produto com o codigo = " + cod);

		Produto produto = null;

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn.prepareStatement("select codigo, nome, descricao from produto where codigo = ?");
			pstmt.setInt(1, cod);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				produto = new Produto();
				produto.setCodigo(rs.getInt("codigo"));
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
			}

		} catch (SQLException e) {
			throw new FalhaAcessoAosDadosException("Falha buscando o registro por c�digo", e);
		} finally {
			this.fechaResultSet(rs);
			this.fechaPreparedStatement(pstmt);
		}
		
		if(produto==null) {
			throw new ProdutoNaoEncontradoException();
		}

		return produto;
	}

	@Override
	public List<Produto> buscaTodos() throws FalhaAcessoAosDadosException {

		List<Produto> produtos = new ArrayList<Produto>();

		Statement stmt = null;
		ResultSet rs = null;

		try {

			stmt = conn.createStatement();
			rs = stmt.executeQuery("select codigo, nome, descricao from produto order by codigo");

			while (rs.next()) {
				Produto produto = new Produto();
				produto.setCodigo(rs.getInt("codigo"));
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
				produtos.add(produto);
			}

		} catch (SQLException e) {
			throw new FalhaAcessoAosDadosException(
					"Falha buscando todos os registros", e);
		} finally {
			this.fechaResultSet(rs);
			this.fechaStatement(stmt);
		}

		return produtos;
	}

	@Override
	public int insereProduto(Produto produto) throws FalhaAcessoAosDadosException {
		System.out.println("Inserindo produto " + produto);
		int inseriu;

		if (produto != null) {
			inseriu = produto.getCodigo();

			PreparedStatement pstmt = null;

			try {

				pstmt = conn.prepareStatement("insert into produto(codigo, nome, descricao) values (?, ?, ?)");

				pstmt.setInt(1, produto.getCodigo());
				pstmt.setString(2, produto.getNome());
				pstmt.setString(3, produto.getDescricao());

				inseriu = pstmt.executeUpdate();
			} catch (SQLException e) {
				throw new FalhaAcessoAosDadosException("Falha ao inserir registro", e);
			} finally {
				this.fechaPreparedStatement(pstmt);
			}
		} else {
			throw new FalhaAcessoAosDadosException("Registro nulo");
		}
		return inseriu;
	}

	@Override
	public int alteraProduto(Produto produto) throws FalhaAcessoAosDadosException {
		System.out.println("Alterando produto " + produto);

		int alterou;

		if (produto != null) {
			alterou = produto.getCodigo();

			PreparedStatement pstmt = null;

			try {

				pstmt = conn.prepareStatement("update produto set nome = ?, descricao = ? where codigo =  ?");

				pstmt.setString(1, produto.getNome());
				pstmt.setString(2, produto.getDescricao());
				pstmt.setInt(3, produto.getCodigo());

				alterou = pstmt.executeUpdate();

			} 
			catch (SQLException e) {
				throw new FalhaAcessoAosDadosException(
						"Falha ao alterar registro", e);
			} 
			finally {
				this.fechaPreparedStatement(pstmt);
			}
		} 
		else {
			throw new FalhaAcessoAosDadosException("Registro nulo");
		}
		return alterou;
	}

	@Override
	public int apagaTodos() throws FalhaAcessoAosDadosException {

		Statement stmt = null;
		int retorno = 0;

		try {

			stmt = conn.createStatement();
			retorno = stmt.executeUpdate("delete from produto");

		} 
		catch (SQLException e) {
			throw new FalhaAcessoAosDadosException(
					"Falha buscando todos os registros", e);
		} 
		finally {
			this.fechaStatement(stmt);
		}

		return retorno;

	}

	@Override
	public int removeProduto(Integer codigo)
			throws FalhaAcessoAosDadosException {

		System.out.println("Removendo o produto com codigo = " + codigo);

		int apagou = 0;

		if (codigo != null) {

			PreparedStatement pstmt = null;

			try {
				pstmt = conn
						.prepareStatement("delete from produto where codigo =  ?");
				pstmt.setInt(1, codigo);
				pstmt.execute();
				apagou = codigo;
			} catch (SQLException e) {
				throw new FalhaAcessoAosDadosException(
						"Falha removendo o registro", e);
			} finally {
				fechaPreparedStatement(pstmt);
			}
		} else {
			throw new FalhaAcessoAosDadosException("Codigo nulo");
		}
		return apagou;
	}
	
}
