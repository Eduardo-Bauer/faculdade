package dao;

import java.util.List;

import exceptions.FalhaAcessoAosDadosException;
import model.Produto;

public class ArquivoProdutoDAO implements ProdutoDAO{
	@Override
	public Produto getProdutoPorCodigo(int cod) throws FalhaAcessoAosDadosException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Produto> buscaTodos() throws FalhaAcessoAosDadosException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insereProduto(Produto produto) throws FalhaAcessoAosDadosException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int alteraProduto(Produto produto) throws FalhaAcessoAosDadosException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int apagaTodos() throws FalhaAcessoAosDadosException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int removeProduto(Integer codigo) throws FalhaAcessoAosDadosException {
		// TODO Auto-generated method stub
		return 0;
	}
}
