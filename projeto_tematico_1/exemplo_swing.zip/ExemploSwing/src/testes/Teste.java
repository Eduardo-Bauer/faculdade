package testes;

import javax.swing.*;

import view.JanelaComJTable;
import view.JanelaComRotulo;
import view.TabelaSimples;

public class Teste {

	public static void main(String[] args) {
		
		//new JFrame().setVisible(true);
		
		//new JanelaComRotulo();
		
		//new JanelaComBotao();
		
		//new JanelaComLista("um r�tulo qualquer");
		
		//new JanelaComMenu("agora com menu");
		
		//new TabelaSimples();
		
		new JanelaComJTable();
		
	}

}
