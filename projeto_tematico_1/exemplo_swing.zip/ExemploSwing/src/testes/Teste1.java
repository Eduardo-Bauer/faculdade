package testes;


import javax.swing.JFrame;

public class Teste1 {

	public static void main(String[] args) {
		

		JFrame janela = new JFrame("Uma Janela");
		
		janela.setSize(400, 400);
		janela.setVisible(true);
		
		
		
	}

}
