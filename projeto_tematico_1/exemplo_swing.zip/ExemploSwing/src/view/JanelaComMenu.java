package view;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

public class JanelaComMenu extends JFrame{

	JMenuBar barraDeMenu ;
    JMenu menuFile,menuHelp ;
    JMenuItem mFItemOpen,mFItemSave ;
    JPanel painel;
    JLabel rotulo;
    JTextField campoDeTexto;
    JButton send;
    JButton reset;
    JTextArea areaDeTexto;
    
    public JanelaComMenu(String rotulo)
    {
    	super(rotulo);
    	this.init();
    }
    
    private void init() {
    
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400, 400);
    	
    	//Criando a barra de menus e adicionando componentes
    	barraDeMenu = new JMenuBar();
        menuFile = new JMenu("FILE");
        menuHelp = new JMenu("Help");
        barraDeMenu.add(menuFile);
        barraDeMenu.add(menuHelp);
        mFItemOpen = new JMenuItem("Open");
        mFItemSave = new JMenuItem("Save as");
        menuFile.add(mFItemOpen);
        menuFile.add(mFItemSave);
        
        //Criando o painel que vai na base e adicionando componentes
        painel = new JPanel(); // o painel n�o � vis�vel apenas ir� conter os componentes
        rotulo = new JLabel("Enter Text");
        campoDeTexto = new JTextField(10); // caixa de texto que aceita at� 10 caracteres
        send = new JButton("Send");
        reset = new JButton("Reset");
        painel.add(rotulo); // Componentes adicionados usando FlowLayout
        painel.add(campoDeTexto);
        painel.add(send);
        painel.add(reset);
        
        // �rea de texto que ficar� no centro da janela
        areaDeTexto = new JTextArea();
        
        //Adicionando os componentes ao "conte�do" da janela
        Container conteudo = this.getContentPane();
        conteudo.add(BorderLayout.SOUTH, painel);
        conteudo.add(BorderLayout.NORTH, barraDeMenu);
        conteudo.add(BorderLayout.CENTER, areaDeTexto);
        
        mFItemOpen.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				areaDeTexto.setText("Abrindo alguma coisa!!");
				
			}
		});
        
        
        this.setVisible(true);
        
        
    }
	
	
	
}
