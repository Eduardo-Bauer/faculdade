package view;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class TabelaSimples extends JFrame{
	private static final long serialVersionUID = 1L;
	
	public TabelaSimples() {
		//cabe�alhos das colunas
        String[] colunas = {"Id", "Nome", "Salario", "Tempo Parcial"};
         
        //dados que estar�o na tabela
        Object[][] dados = {
            {1, "Jo�o", 4000.0, false },
            {2, "Maria", 7000.0, false },
            {3, "Carlso", 6000.0, true },
        };
        //criando a tabela
        JTable tabela = new JTable(dados, colunas);
         
        //add the table to the frame
        this.add(new JScrollPane(tabela));
         
        this.setTitle("Tabela Simples");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);    	
        this.setSize(300,200);
        
        this.setVisible(true);
	}

	
	
	
}
