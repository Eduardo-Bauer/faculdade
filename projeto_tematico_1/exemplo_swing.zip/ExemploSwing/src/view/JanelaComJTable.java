package view;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

import model.MeuTableModel;

public class JanelaComJTable extends JFrame {
	private static final long serialVersionUID = 1L;

	JTable tabela = new JTable(new MeuTableModel());
	JScrollPane scrollPane ;
	
	public JanelaComJTable() {
		this.inicializa();
	}

	private void inicializa() {
				
		TableColumn column = null;
		for (int i = 0; i < 5; i++) {
		    column = tabela.getColumnModel().getColumn(i);
		    if (i == 2) {
		        column.setPreferredWidth(200); //third column is bigger
		    } else {
		        column.setPreferredWidth(50);
		    }
		}
		
		tabela.setAutoCreateRowSorter(true);
		
		
		
		scrollPane= new JScrollPane(tabela);
		tabela.setFillsViewportHeight(true);
		this.getContentPane().add(scrollPane);

		this.setDefaultCloseOperation(EXIT_ON_CLOSE);    	
        this.setSize(300,200);
		
		this.setVisible(true);
		
	}
	
	
}
