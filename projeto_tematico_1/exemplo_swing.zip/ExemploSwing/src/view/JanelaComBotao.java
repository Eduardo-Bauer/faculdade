package view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JanelaComBotao extends JFrame  {
	
		private JButton botao1 ;
		private JTextField campo ;

		public JanelaComBotao() {
			inicializa();
		}

		private void inicializa()
		{
			botao1 = new JButton("Ok");
			campo = new JTextField("Um texto qualquer");
			
			Container c = this.getContentPane();
			c.setLayout(new FlowLayout());

			c.add(botao1);
			c.add(campo);
			
					
//			ActionListener ouvidor = new  ActionListener(){ 
//				  public void actionPerformed(ActionEvent e) {
//					botao1.setText(campo.getText());
//				  }
//			   };
			   
		    botao1.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					botao1.setText(campo.getText());
				}
			});
		    
//			ActionListener ouvidor = new TratadorDeClick();	
			
			
			
//			botao1.addActionListener(new UmaClasseInterna());
			

			this.setSize(200,150);
			this.setVisible(true);
		}
		
		
//		private class UmaClasseInterna implements ActionListener {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				
//				botao1.setText(campo.getText());
//			}
//			
//		}
	
}






