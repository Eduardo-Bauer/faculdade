package view;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

public class JanelaComLista extends JFrame
{
    // painel1 
    private JPanel painel1 = new JPanel();
    private JScrollPane paneComBarras;
    private JList<String> listaDeItens;
    
    // painel2
    private JPanel painel2 = new JPanel();
    private JTextField caixa = new JTextField("valor inicial");
    
    Container conteudo ;
    
    public JanelaComLista(String rotulo)
    {
    	super(rotulo);
    	
    	this.setDefaultCloseOperation(EXIT_ON_CLOSE);    	
        this.setSize(300,200);
        
        conteudo = this.getContentPane();
        conteudo.setLayout(new GridLayout(1,2));

        // acertando a lista
        String[] osElementosDaLista = {"um","dois","tres","quatro","cinco","seis",
                                       "um item um pouco mais longo","oito","nove",
                                       "dez","onze","doze"} ;
                                       
        listaDeItens = new JList<String>(osElementosDaLista);
        
        //listaDeItens.addListSelectionListener(new TrataDaSelecaoNaLista());
        
        listaDeItens.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				caixa.setText( (String) listaDeItens.getSelectedValue()  );
	            conteudo.validate();
			}
        	
        });

        
        paneComBarras = new JScrollPane(listaDeItens);
        paneComBarras.setSize(200,300);

        // Layouts para os pain�is        
        painel2.setLayout(new FlowLayout()); 
        painel1.setLayout(new BorderLayout());
        
        // adicionando componentes aos pain�is
        painel1.add(paneComBarras,BorderLayout.CENTER);     
        painel2.add(caixa);
        conteudo.add(painel1);
        conteudo.add(painel2);
        
        this.setVisible(true);
    }
    
    
    private class TrataDaSelecaoNaLista implements ListSelectionListener  
    {
        public void valueChanged(ListSelectionEvent e) 
        {
            caixa.setText( (String) listaDeItens.getSelectedValue()  );
            conteudo.validate();
        }
    }

}








