package view;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class JanelaComRotulo extends JFrame
{
    
    private JLabel rotulo1 ;
    private JLabel rotulo2 ;
    private JButton botao1 ;
	private JTextField campo ;
	
    public JanelaComRotulo() 
    {
        rotulo1 = new JLabel("Um Rotulo") ;
        
        rotulo1.setToolTipText("Este e o rotulo 1");
        rotulo1.setOpaque(true);
        rotulo1.setBackground(new Color(154,165,127));
        
        rotulo2 = new JLabel("Outro") ;
        
        rotulo2.setOpaque(true);
        rotulo2.setBackground(new Color(248,213,131));
        rotulo2.setToolTipText("Este e o rotulo 2");
        
        botao1 = new JButton("Ok");
        
		campo = new JTextField("Um texto qualquer");
        
        Container conteudo = this.getContentPane();

        conteudo.setLayout(new GridLayout(2,2));

        //conteudo.setLayout(new FlowLayout());
        
        conteudo.add(rotulo1);
        conteudo.add(botao1);
        conteudo.add(campo);
        conteudo.add(rotulo2);
        
        
        this.setSize(300,150);
        this.setVisible(true);        
    }
    
} 
