package model;

import javax.swing.table.AbstractTableModel;

public class MeuTableModel extends AbstractTableModel{
	private static final long serialVersionUID = 1L;

	
	String[] columnNames = {"First Name", "Last Name", "Sport", "# of Years", "Vegetarian"};
	Object[][] data = { 
						{"Kathy", "Smith", "Snowboarding", 5, false},
		    			{"John", "Doe", "Rowing", 3, true},
		    			{"Sue", "Black", "Knitting", 2, false},
		    			{"Jane", "White", "Speed reading", 20, true},
		    			{"Joe", "Brown", "Pool", 10, false}		
		    		  };
	
	
	@Override
	public int getColumnCount() {
        return columnNames.length;
    }

	@Override
	public int getRowCount() {
        return data.length;
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
	public Object getValueAt(int row, int col) {
        return data[row][col];
    }

    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }

    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {
        //Note that the data/cell address is constant,
        //no matter where the cell appears onscreen.
        if (col < 2) {
            return false;
        } else {
            return true;
        }
    }

    /*
     * Don't need to implement this method unless your table's
     * data can change.
     */
    public void setValueAt(Object value, int row, int col) {
        data[row][col] = value;
        fireTableCellUpdated(row, col);
    }
	
	

	

}
